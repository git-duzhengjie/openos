/* ============================================================
 * openos - VFS 实现 (Phase 3)
 * ============================================================ */

#include "vfs.h"
#include "serial.h"
#include "pmm.h"
#include "string.h"
#include "ramfs.h"
#include "tmpfs.h"
#include "pfs.h"
#include "chardev.h"
#include "blockdev.h"
#include "process.h"
#include "input_buffer.h"
#include "rtc.h"

#ifndef NULL
#define NULL ((void*)0)
#endif

static int vfs_callback_is_sane(const void *fn) {
    uint32_t addr = (uint32_t)fn;
    /* Kernel callbacks must never be tiny integer values such as fd=3. */
    return addr >= 0x00100000u;
}

/* ---- 全局状态 ---- */
static dentry_t *root_dentry;
static inode_t  *root_inode;
static mount_t  *mount_list;

#define MAX_INODES 192
static inode_t  inode_pool[MAX_INODES];
static uint32_t next_ino = 1;

#define MAX_DENTRY 192
static dentry_t dentry_pool[MAX_DENTRY];

#define MAX_MOUNTS 16
static mount_t mount_pool[MAX_MOUNTS];

#define MAX_SYMLINKS 32
static char symlink_target_pool[MAX_SYMLINKS][MAX_PATH];
static uint8_t symlink_target_used[MAX_SYMLINKS];

/* ============================================================
 * 小工具函数
 * ============================================================ */

#define VFS_FILE_TYPE_MASK 0xF000

static int vfs_is_dir(inode_t *ip) {
    return ip && ((ip->mode & VFS_FILE_TYPE_MASK) == FS_DIR);
}

static int vfs_is_file(inode_t *ip) {
    return ip && ((ip->mode & VFS_FILE_TYPE_MASK) == FS_FILE);
}

static int vfs_is_symlink(inode_t *ip) {
    return ip && ((ip->mode & VFS_FILE_TYPE_MASK) == FS_SYMLINK);
}

static char *alloc_symlink_target(void) {
    for (int i = 0; i < MAX_SYMLINKS; i++) {
        if (!symlink_target_used[i]) {
            symlink_target_used[i] = 1;
            symlink_target_pool[i][0] = 0;
            return symlink_target_pool[i];
        }
    }
    return NULL;
}

static void free_symlink_target(void *ptr) {
    if (!ptr) return;
    for (int i = 0; i < MAX_SYMLINKS; i++) {
        if (ptr == symlink_target_pool[i]) {
            symlink_target_used[i] = 0;
            symlink_target_pool[i][0] = 0;
            return;
        }
    }
}

// static int vfs_is_chardev(inode_t *ip) { return ip && ((ip->mode & VFS_FILE_TYPE_MASK) == FS_CHAR_DEVICE); }
// static int vfs_is_blockdev(inode_t *ip) { return ip && ((ip->mode & VFS_FILE_TYPE_MASK) == FS_BLOCK_DEVICE); }

// static int path_copy_name(char *dst, const char *src, uint32_t len) { if (!dst||!src||len==0||len>=MAX_NAME) return -1; for(uint32_t i=0;i<len;i++)dst[i]=src[i]; dst[len]=0; return 0; }

static int is_open_write(int flags) {
    int acc = flags & 3;
    return acc == O_WRONLY || acc == O_RDWR;
}

static int is_open_read(int flags) {
    int acc = flags & 3;
    return acc == O_RDONLY || acc == O_RDWR;
}

static int vfs_inode_access(inode_t *inode, uint32_t req) {
    if (!inode) return -1;

    uint32_t uid = proc_current_uid();
    uint32_t gid = proc_current_gid();
    if (uid == 0) return 0;

    uint32_t perm = inode->mode & S_IRWXUGO;
    uint32_t allowed;
    if (uid == inode->uid) {
        allowed = (perm & S_IRWXU) >> 6;
    } else if (gid == inode->gid) {
        allowed = (perm & S_IRWXG) >> 3;
    } else {
        allowed = perm & S_IRWXO;
    }

    return ((allowed & req) == req) ? 0 : -1;
}

static int vfs_can_read(inode_t *inode) {
    return vfs_inode_access(inode, 4);
}

static int vfs_can_write(inode_t *inode) {
    return vfs_inode_access(inode, 2);
}

static int vfs_can_exec(inode_t *inode) {
    return vfs_inode_access(inode, 1);
}

static void vfs_repair_memory_inode(inode_t *ip, inode_t *parent) {
    if (!ip || !vfs_is_file(ip)) return;
    if (ip->fs_type == PFS_MAGIC) return;
    if (ip->fs_type != 0 && ip->ops && ip->ops->write) return;

    serial_write("[VFS-R] repair memory inode mode=");
    serial_write_hex(ip->mode);
    serial_write(" old_fs=");
    serial_write_hex(ip->fs_type);
    serial_write(" parent_fs=");
    serial_write_hex(parent ? parent->fs_type : 0);
    serial_write("\n");

    uint32_t parent_fs = parent ? parent->fs_type : 0;
    if (parent_fs == TMPFS_MAGIC) {
        tmpfs_setup_inode(ip, ip->mode);
    } else {
        ramfs_setup_inode(ip, ip->mode);
    }

    serial_write("[VFS-R] repaired fs=");
    serial_write_hex(ip->fs_type);
    serial_write(" ops=");
    serial_write_hex((uint32_t)ip->ops);
    serial_write(" write=");
    serial_write_hex((uint32_t)((ip->ops && ip->ops->write) ? ip->ops->write : 0));
    serial_write(" fs_data=");
    serial_write_hex((uint32_t)ip->fs_data);
    serial_write("\n");
}

/* ============================================================
 * inode / dentry / mount 分配
 * ============================================================ */

/* ============================================================
 * wall-clock 时间辅助 (依赖 CMOS RTC)
 * ============================================================ */

int vfs_now(vfs_time_t *out) {
    rtc_time_t rt;
    if (!out) return -1;
    if (rtc_read_time(&rt) != 0) {
        /* RTC 不可用, 填 0 表示未知 */
        out->year = 0; out->month = 0; out->day = 0;
        out->hour = 0; out->minute = 0; out->second = 0;
        out->_pad = 0;
        return -1;
    }
    out->year   = rt.year;
    out->month  = rt.month;
    out->day    = rt.day;
    out->hour   = rt.hour;
    out->minute = rt.minute;
    out->second = rt.second;
    out->_pad   = 0;
    return 0;
}

void vfs_touch_mtime(inode_t *ip) {
    if (!ip) return;
    vfs_now(&ip->mtime);
    /* mtime 变动也算 atime 变动 */
    ip->atime = ip->mtime;
}

void vfs_touch_atime(inode_t *ip) {
    if (!ip) return;
    vfs_now(&ip->atime);
}

static inode_t *alloc_inode(void) {
    for (int i = 0; i < MAX_INODES; i++) {
        if (inode_pool[i].ref_count == 0) {
            inode_t *ip = &inode_pool[i];
            memset(ip, 0, sizeof(inode_t));
            ip->ino = next_ino++;
            ip->ref_count = 1;
            ip->nlinks = 1;
            /* 新 inode 默认以当前时间为 ctime/mtime/atime */
            vfs_now(&ip->ctime);
            ip->mtime = ip->ctime;
            ip->atime = ip->ctime;
            return ip;
        }
    }
    return NULL;
}

static void free_inode(inode_t *ip) {
    if (!ip) return;
    if (ip->ref_count > 0) ip->ref_count--;
    if (ip->ref_count == 0) {
        memset(ip, 0, sizeof(inode_t));
    }
}

static dentry_t *alloc_dentry(void) {
    for (int i = 0; i < MAX_DENTRY; i++) {
        if (dentry_pool[i].inode == NULL && dentry_pool[i].name[0] == 0) {
            dentry_t *d = &dentry_pool[i];
            memset(d, 0, sizeof(dentry_t));
            return d;
        }
    }
    return NULL;
}

static void free_dentry(dentry_t *d) {
    if (!d) return;
    if (d->inode && d->inode->ref_count <= 1 && vfs_is_symlink(d->inode))
        free_symlink_target(d->inode->fs_data);
    if (d->inode) free_inode(d->inode);
    memset(d, 0, sizeof(dentry_t));
}

static mount_t *alloc_mount(void) {
    for (int i = 0; i < MAX_MOUNTS; i++) {
        if (mount_pool[i].fs == NULL) {
            memset(&mount_pool[i], 0, sizeof(mount_t));
            return &mount_pool[i];
        }
    }
    return NULL;
}

static void free_mount(mount_t *m) {
    if (!m) return;
    memset(m, 0, sizeof(mount_t));
}

static void add_child(dentry_t *parent, dentry_t *child) {
    if (!parent || !child) return;
    child->parent = parent;
    child->sibling = parent->child;
    parent->child = child;
}

static void detach_child(dentry_t *child) {
    if (!child || !child->parent) return;
    dentry_t *parent = child->parent;
    dentry_t **pp = &parent->child;
    while (*pp) {
        if (*pp == child) {
            *pp = child->sibling;
            child->parent = NULL;
            child->sibling = NULL;
            return;
        }
        pp = &(*pp)->sibling;
    }
}

static dentry_t *find_child(dentry_t *parent, const char *name) {
    if (!parent || !name) return NULL;
    dentry_t *c = parent->child;
    while (c) {
        if (strcmp(c->name, name) == 0) return c;
        c = c->sibling;
    }
    return NULL;
}

static dentry_t *resolve_mount(dentry_t *d) {
    while (d && d->mount) d = d->mount;
    return d;
}

static int has_children(dentry_t *d) {
    d = resolve_mount(d);
    return d && d->child != NULL;
}

/* ============================================================
 * 设备文件 ops
 * ============================================================ */

static int vfs_chardev_open(file_t *f) {
    if (!f || !f->inode) return -1;
    return chardev_open((chardev_t *)f->inode->fs_data);
}

static int vfs_chardev_close(file_t *f) {
    if (!f || !f->inode) return -1;
    return chardev_close((chardev_t *)f->inode->fs_data);
}

static int vfs_chardev_read(file_t *f, void *buf, uint32_t count) {
    if (!f || !f->inode) return -1;
    return chardev_read((chardev_t *)f->inode->fs_data, buf, count);
}

static int vfs_chardev_write(file_t *f, const void *buf, uint32_t count) {
    if (!f || !f->inode) return -1;
    return chardev_write((chardev_t *)f->inode->fs_data, buf, count);
}

static file_ops_t vfs_chardev_ops = {
    .open = vfs_chardev_open,
    .close = vfs_chardev_close,
    .read = vfs_chardev_read,
    .write = vfs_chardev_write,
    .seek = NULL,
    .truncate = NULL,
    .fsync = NULL,
    .readdir = NULL,
};

static int vfs_blockdev_open(file_t *f) {
    if (!f || !f->inode) return -1;
    return blockdev_open((blockdev_t *)f->inode->fs_data);
}

static int vfs_blockdev_close(file_t *f) {
    if (!f || !f->inode) return -1;
    return blockdev_close((blockdev_t *)f->inode->fs_data);
}

static int vfs_blockdev_read(file_t *f, void *buf, uint32_t count) {
    if (!f || !f->inode || !buf) return -1;
    blockdev_t *dev = (blockdev_t *)f->inode->fs_data;
    if (!dev || dev->sector_size == 0) return -1;
    if ((f->offset % dev->sector_size) != 0 || (count % dev->sector_size) != 0) return -1;
    int r = blockdev_read_blocks(dev, f->offset / dev->sector_size,
                                 count / dev->sector_size, buf);
    if (r < 0) return r;
    f->offset += count;
    return (int)count;
}

static int vfs_blockdev_write(file_t *f, const void *buf, uint32_t count) {
    if (!f || !f->inode || !buf) return -1;
    blockdev_t *dev = (blockdev_t *)f->inode->fs_data;
    if (!dev || dev->sector_size == 0) return -1;
    if ((f->offset % dev->sector_size) != 0 || (count % dev->sector_size) != 0) return -1;
    int r = blockdev_write_blocks(dev, f->offset / dev->sector_size,
                                  count / dev->sector_size, buf);
    if (r < 0) return r;
    f->offset += count;
    return (int)count;
}

static int vfs_blockdev_seek(file_t *f, int offset, int whence) {
    if (!f || !f->inode) return -1;
    uint32_t size = blockdev_size_bytes((blockdev_t *)f->inode->fs_data);
    uint32_t new_off;
    switch (whence) {
    case SEEK_SET:
        if (offset < 0) return -1;
        new_off = (uint32_t)offset;
        break;
    case SEEK_CUR:
        if (offset < 0 && (uint32_t)(-offset) > f->offset) return -1;
        new_off = f->offset + offset;
        break;
    case SEEK_END:
        if (offset < 0 && (uint32_t)(-offset) > size) return -1;
        new_off = size + offset;
        break;
    default:
        return -1;
    }
    if (new_off > size) return -1;
    f->offset = new_off;
    return (int)new_off;
}

static int vfs_blockdev_fsync(file_t *f) {
    if (!f || !f->inode) return -1;
    return blockdev_flush((blockdev_t *)f->inode->fs_data);
}

static file_ops_t vfs_blockdev_ops = {
    .open = vfs_blockdev_open,
    .close = vfs_blockdev_close,
    .read = vfs_blockdev_read,
    .write = vfs_blockdev_write,
    .seek = vfs_blockdev_seek,
    .truncate = NULL,
    .fsync = vfs_blockdev_fsync,
    .readdir = NULL,
};

/* ============================================================
 * 路径规范化与解析
 * ============================================================ */

/* ============================================================
 * 进程 cwd / fd table 辅助
 * ============================================================ */
static file_t *fallback_fds[MAX_FD];
static int fallback_fds_inited = 0;
static char fallback_cwd[MAX_PATH] = "/";

static process_t *vfs_current_process(void) {
    thread_t *cur = sched_get_current();
    if (!cur || cur->pid == 0) return NULL;
    return proc_find(cur->pid);
}

static char *vfs_get_cwd(void) {
    process_t *p = vfs_current_process();
    if (p) return p->cwd;
    return fallback_cwd;
}

static file_t **get_current_fd_table(void) {
    process_t *p = vfs_current_process();
    if (p) return (file_t **)p->fds;

    if (!fallback_fds_inited) {
        memset(fallback_fds, 0, sizeof(fallback_fds));
        fallback_fds_inited = 1;
    }
    return fallback_fds;
}

static char *vfs_resolve_to_absolute(const char *path, char *buf, uint32_t buf_size) {
    if (!path || !buf || buf_size < 2) return NULL;
    if (path[0] == '/') {
        strncpy(buf, path, buf_size - 1);
        buf[buf_size - 1] = 0;
        return buf;
    }
    const char *cwd = vfs_get_cwd();
    uint32_t cwd_len = (uint32_t)strlen(cwd);
    uint32_t path_len = (uint32_t)strlen(path);
    if (cwd_len + 1 + path_len + 1 > buf_size) return NULL;
    strncpy(buf, cwd, buf_size - 1);
    if (cwd_len > 0 && buf[cwd_len - 1] != '/') {
        buf[cwd_len] = '/';
        cwd_len++;
    }
    strncpy(buf + cwd_len, path, buf_size - 1 - cwd_len);
    buf[buf_size - 1] = 0;
    return buf;
}

int vfs_normalize_path(const char *path, char *out, uint32_t out_size) {
    if (!path || !out || out_size < 2) return -1;

    char abs_buf[MAX_PATH];
    const char *abs = vfs_resolve_to_absolute(path, abs_buf, sizeof(abs_buf));
    if (!abs) return -1;

    char parts[32][MAX_NAME];
    uint32_t depth = 0;
    uint32_t i = 0;

    while (abs[i]) {
        while (abs[i] == '/') i++;
        if (!abs[i]) break;

        char name[MAX_NAME];
        uint32_t n = 0;
        while (abs[i] && abs[i] != '/') {
            if (n + 1 >= MAX_NAME) return -1;
            name[n++] = abs[i++];
        }
        name[n] = 0;

        if (strcmp(name, ".") == 0) {
            continue;
        }
        if (strcmp(name, "..") == 0) {
            if (depth > 0) depth--;
            continue;
        }
        if (depth >= 32) return -1;
        strcpy(parts[depth++], name);
    }

    uint32_t pos = 0;
    out[pos++] = '/';
    if (depth == 0) {
        out[pos] = 0;
        return 0;
    }

    for (uint32_t p = 0; p < depth; p++) {
        uint32_t n = (uint32_t)strlen(parts[p]);
        if (pos + n + 1 >= out_size) return -1;
        for (uint32_t j = 0; j < n; j++) out[pos++] = parts[p][j];
        if (p + 1 < depth) out[pos++] = '/';
    }
    out[pos] = 0;
    return 0;
}

static int split_parent_path(const char *path, char *parent_out, char *name_out) {
    char norm[MAX_PATH];
    if (vfs_normalize_path(path, norm, sizeof(norm)) < 0) return -1;
    if (strcmp(norm, "/") == 0) return -1;

    int len = (int)strlen(norm);
    int slash = len - 1;
    while (slash > 0 && norm[slash] != '/') slash--;

    const char *name = &norm[slash + 1];
    if (!name[0] || strlen(name) >= MAX_NAME) return -1;
    strcpy(name_out, name);

    if (slash == 0) {
        strcpy(parent_out, "/");
    } else {
        if ((uint32_t)slash >= MAX_PATH) return -1;
        for (int i = 0; i < slash; i++) parent_out[i] = norm[i];
        parent_out[slash] = 0;
    }
    return 0;
}

static dentry_t *vfs_path_lookup_internal_depth(const char *path, int follow_final, int depth) {
    if (!root_dentry || !path || depth > 8) return NULL;

    char norm[MAX_PATH];
    if (vfs_normalize_path(path, norm, sizeof(norm)) < 0) return NULL;
    if (strcmp(norm, "/") == 0) {
        return resolve_mount(root_dentry);
    }

    dentry_t *cur = root_dentry;
    uint32_t i = 1;
    while (norm[i]) {
        char name[MAX_NAME];
        uint32_t n = 0;
        while (norm[i] && norm[i] != '/') {
            if (n + 1 >= MAX_NAME) return NULL;
            name[n++] = norm[i++];
        }
        name[n] = 0;
        while (norm[i] == '/') i++;

        cur = resolve_mount(cur);
        if (!vfs_is_dir(cur ? cur->inode : NULL)) return NULL;
        cur = find_child(cur, name);
        if (!cur) return NULL;

        int final = norm[i] == 0;
        if (vfs_is_symlink(cur->inode) && (!final || follow_final)) {
            const char *target = (const char *)cur->inode->fs_data;
            char next[MAX_PATH];
            if (!target || !target[0]) return NULL;
            if (target[0] == '/') {
                strncpy(next, target, sizeof(next) - 1);
                next[sizeof(next) - 1] = 0;
            } else {
                uint32_t slash = 0;
                uint32_t tlen = (uint32_t)strlen(target);
                uint32_t pos = 0;
                for (uint32_t j = 0; norm[j]; j++) {
                    if (norm[j] == '/') slash = j;
                }
                if (slash == 0) {
                    if (1 + tlen + 1 > sizeof(next)) return NULL;
                    next[pos++] = '/';
                } else {
                    if (slash + 1 + tlen + 1 > sizeof(next)) return NULL;
                    for (uint32_t j = 0; j < slash; j++) next[pos++] = norm[j];
                    next[pos++] = '/';
                }
                strcpy(next + pos, target);
            }
            if (!final) {
                uint32_t len = (uint32_t)strlen(next);
                uint32_t rest = (uint32_t)strlen(&norm[i]);
                if (len + 1 + rest + 1 > sizeof(next)) return NULL;
                next[len++] = '/';
                strcpy(next + len, &norm[i]);
            }
            return vfs_path_lookup_internal_depth(next, follow_final, depth + 1);
        }

        if (!final) {
            cur = resolve_mount(cur);
        } else if (follow_final) {
            cur = resolve_mount(cur);
        }
    }
    return cur;
}

static dentry_t *vfs_path_lookup_internal(const char *path, int follow_final) {
    return vfs_path_lookup_internal_depth(path, follow_final, 0);
}

dentry_t *vfs_path_lookup(const char *path) {
    return vfs_path_lookup_internal(path, 1);
}

/* ============================================================
 * VFS 初始化与内部创建辅助
 * ============================================================ */

void vfs_init_fds_for_process(void *proc) {
    process_t *p = (process_t *)proc;
    if (!p) return;
    for (int i = 0; i < MAX_FD; i++) {
        p->fds[i] = NULL;
        p->fd_flags[i] = 0;
    }
    strncpy(p->cwd, "/", sizeof(p->cwd) - 1);
    p->cwd[sizeof(p->cwd) - 1] = 0;
}

void vfs_init_fds(void) {
    for (int i = 0; i < MAX_FD; i++) fallback_fds[i] = NULL;
    strncpy(fallback_cwd, "/", sizeof(fallback_cwd)-1);
    fallback_cwd[sizeof(fallback_cwd)-1] = 0;
}

void vfs_init(void) {
    memset(inode_pool, 0, sizeof(inode_pool));
    memset(dentry_pool, 0, sizeof(dentry_pool));
    memset(mount_pool, 0, sizeof(mount_pool));
    memset(symlink_target_used, 0, sizeof(symlink_target_used));
    mount_list = NULL;
    next_ino = 1;
    vfs_init_fds();

    root_inode = alloc_inode();
    root_inode->mode = FS_DIR | S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH;
    root_inode->uid = 0;
    root_inode->gid = 0;
    root_inode->ops = NULL;

    root_dentry = alloc_dentry();
    strcpy(root_dentry->name, "/");
    root_dentry->inode = root_inode;
    root_dentry->parent = root_dentry;

    ramfs_setup_inode(root_inode, root_inode->mode);

    serial_write("[VFS] initialized\n");
}

dentry_t *vfs_create_node_under(dentry_t *parent, const char *name,
                                uint32_t mode, file_ops_t *ops,
                                void *fs_data, uint32_t size) {
    parent = resolve_mount(parent);
    if (!parent || !vfs_is_dir(parent->inode) || !name || !name[0]) return NULL;
    if (strlen(name) >= MAX_NAME) return NULL;
    if (find_child(parent, name)) return NULL;

    inode_t *ip = alloc_inode();
    if (!ip) return NULL;
    ip->mode = mode;
    ip->uid = proc_current_uid();
    ip->gid = proc_current_gid();
    ip->size = size;
    ip->fs_data = fs_data;
    ip->ops = ops;
    ip->fs_type = parent->inode ? parent->inode->fs_type : 0;

    uint32_t type = mode & VFS_FILE_TYPE_MASK;
    if (!ops && (type == FS_FILE || type == FS_DIR)) {
        if (parent->inode && parent->inode->fs_type == TMPFS_MAGIC) {
            tmpfs_setup_inode(ip, mode);
        } else if (parent->inode && parent->inode->fs_type == PFS_MAGIC) {
            /* PFS binds inode ops/fs_data after the persistent node is allocated. */
        } else {
            ramfs_setup_inode(ip, mode);
        }
    }

    dentry_t *d = alloc_dentry();
    if (!d) {
        free_inode(ip);
        return NULL;
    }
    strcpy(d->name, name);
    d->inode = ip;
    add_child(parent, d);
    return d;
}

static dentry_t *create_regular_file(dentry_t *parent, const char *name, uint32_t mode) {
    uint32_t perm = mode & S_IRWXUGO;
    if (!perm) perm = S_IRUSR | S_IWUSR;

    dentry_t *d = vfs_create_node_under(parent, name, FS_FILE | perm, NULL, NULL, 0);
    if (d && d->inode) {
        inode_t *parent_inode = parent ? resolve_mount(parent)->inode : NULL;
        vfs_repair_memory_inode(d->inode, parent_inode);
    }
    return d;
}

/* ============================================================
 * fd 管理 / pipe
 * ============================================================ */

#define VFS_PIPE_CAPACITY 512
#define VFS_MAX_PIPES    32

typedef struct vfs_pipe {
    int used;
    int readers;
    int writers;
    uint32_t head;
    uint32_t tail;
    uint32_t count;
    char buffer[VFS_PIPE_CAPACITY];
} vfs_pipe_t;

static vfs_pipe_t pipe_pool[VFS_MAX_PIPES];
static file_ops_t vfs_pipe_read_ops;
static file_ops_t vfs_pipe_write_ops;

static vfs_pipe_t *vfs_pipe_alloc_obj(void) {
    for (int i = 0; i < VFS_MAX_PIPES; i++) {
        if (!pipe_pool[i].used) {
            memset(&pipe_pool[i], 0, sizeof(vfs_pipe_t));
            pipe_pool[i].used = 1;
            pipe_pool[i].readers = 1;
            pipe_pool[i].writers = 1;
            return &pipe_pool[i];
        }
    }
    return NULL;
}

static void vfs_pipe_release_obj(vfs_pipe_t *p) {
    if (!p) return;
    if (p->readers <= 0 && p->writers <= 0) {
        memset(p, 0, sizeof(vfs_pipe_t));
    }
}

static int vfs_pipe_read(file_t *file, void *buf, uint32_t count) {
    if (!file || !buf) return -1;
    vfs_pipe_t *p = (vfs_pipe_t *)file->fs_data;
    if (!p || !p->used) return -1;
    if (count == 0) return 0;

    char *out = (char *)buf;
    uint32_t n = 0;
    while (n == 0) {
        while (n < count && p->count > 0) {
            out[n++] = p->buffer[p->tail];
            p->tail = (p->tail + 1) % VFS_PIPE_CAPACITY;
            p->count--;
        }
        if (n > 0) break;
        if (p->writers <= 0) return 0;
        sched_yield();
    }
    return (int)n;
}

static int vfs_pipe_poll(file_t *file, uint32_t events) {
    uint32_t revents = 0;
    vfs_pipe_t *p;

    if (!file)
        return VFS_POLLERR;
    p = (vfs_pipe_t *)file->fs_data;
    if (!p || !p->used)
        return VFS_POLLERR;

    if ((events & VFS_POLLIN) && file->ops == &vfs_pipe_read_ops) {
        if (p->count > 0 || p->writers <= 0)
            revents |= VFS_POLLIN;
        if (p->writers <= 0)
            revents |= VFS_POLLHUP;
    }
    if ((events & VFS_POLLOUT) && file->ops == &vfs_pipe_write_ops) {
        if (p->readers <= 0) {
            revents |= VFS_POLLERR | VFS_POLLHUP;
        } else if (p->count < VFS_PIPE_CAPACITY) {
            revents |= VFS_POLLOUT;
        }
    }

    return (int)revents;
}

static int vfs_pipe_write(file_t *file, const void *buf, uint32_t count) {
    if (!file || !buf) return -1;
    vfs_pipe_t *p = (vfs_pipe_t *)file->fs_data;
    if (!p || !p->used) return -1;
    if (count == 0) return 0;
    if (p->readers <= 0) return -1;

    const char *in = (const char *)buf;
    uint32_t n = 0;
    while (n < count) {
        while (p->count >= VFS_PIPE_CAPACITY) {
            if (p->readers <= 0) return n > 0 ? (int)n : -1;
            sched_yield();
        }
        p->buffer[p->head] = in[n++];
        p->head = (p->head + 1) % VFS_PIPE_CAPACITY;
        p->count++;
    }
    return (int)n;
}

static int vfs_pipe_close(file_t *file) {
    if (!file) return -1;
    vfs_pipe_t *p = (vfs_pipe_t *)file->fs_data;
    if (!p) return 0;
    if (file->ops == &vfs_pipe_read_ops) {
        if (p->readers > 0) p->readers--;
    } else if (file->ops == &vfs_pipe_write_ops) {
        if (p->writers > 0) p->writers--;
    }
    vfs_pipe_release_obj(p);
    file->fs_data = NULL;
    return 0;
}

static file_ops_t vfs_pipe_read_ops = {
    .read = vfs_pipe_read,
    .poll = vfs_pipe_poll,
    .close = vfs_pipe_close,
};

static file_ops_t vfs_pipe_write_ops = {
    .write = vfs_pipe_write,
    .poll = vfs_pipe_poll,
    .close = vfs_pipe_close,
};

int vfs_alloc_fd(void) {
    file_t **fds = get_current_fd_table();

    /* Reserve fd 0/1/2 for stdin/stdout/stderr.  They are handled by
     * the syscall layer for now, so regular VFS opens start at fd 3.
     */
    for (int i = 3; i < MAX_FD; i++) {
        if (!fds[i]) return i;
    }
    return -1;
}

file_t *vfs_get_file(int fd) {
    if (fd < 0 || fd >= MAX_FD) return NULL;
    file_t **fds = get_current_fd_table();
    return fds[fd];
}

int vfs_put_file(int fd, file_t *file) {
    if (fd < 0 || fd >= MAX_FD) return -1;
    file_t **fds = get_current_fd_table();
    fds[fd] = file;
    return 0;
}

static void vfs_file_get(file_t *f) {
    if (f) f->ref_count++;
}

static void vfs_file_put(file_t *f) {
    if (!f) return;
    if (f->ref_count > 1) {
        f->ref_count--;
        return;
    }
    if (f->ops && f->ops->close) {
        if (!vfs_callback_is_sane((const void *)f->ops->close)) {
            serial_write("[VFS] bad close callback f=");
            serial_write_hex((uint32_t)f);
            serial_write(" inode=");
            serial_write_hex((uint32_t)f->inode);
            serial_write(" ops=");
            serial_write_hex((uint32_t)f->ops);
            serial_write(" close=");
            serial_write_hex((uint32_t)f->ops->close);
            serial_write("\n");
        } else {
            f->ops->close(f);
        }
    }
    pmm_free_page(f);
}

int vfs_get_fd_flags(int fd) {
    if (fd < 0 || fd >= MAX_FD) return -1;
    process_t *proc = vfs_current_process();
    if (!proc) return 0;
    return (int)proc->fd_flags[fd];
}

int vfs_set_fd_flags(int fd, uint32_t flags) {
    if (fd < 0 || fd >= MAX_FD) return -1;
    process_t *proc = vfs_current_process();
    if (!proc) return -1;
    proc->fd_flags[fd] = flags;
    return 0;
}

int vfs_mark_fd_cloexec(int fd) {
    int flags = vfs_get_fd_flags(fd);
    if (flags < 0) return -1;
    return vfs_set_fd_flags(fd, (uint32_t)flags | FD_CLOEXEC);
}

int vfs_poll_fd(int fd, uint32_t events) {
    file_t *file;
    uint32_t revents = 0;

    if (fd == 0) {
        if (events & VFS_POLLIN) {
            if (input_has_data() || input_has_eof())
                revents |= VFS_POLLIN;
        }
        return (int)revents;
    }
    if (fd == 1 || fd == 2)
        return (events & VFS_POLLOUT) ? VFS_POLLOUT : 0;

    file = vfs_get_file(fd);
    if (!file)
        return VFS_POLLERR;
    if (file->ops && file->ops->poll)
        return file->ops->poll(file, events);

    if ((events & VFS_POLLIN) && file->ops && file->ops->read)
        revents |= VFS_POLLIN;
    if ((events & VFS_POLLOUT) && file->ops && file->ops->write)
        revents |= VFS_POLLOUT;
    return (int)revents;
}

int vfs_clear_fd_cloexec(int fd) {
    int flags = vfs_get_fd_flags(fd);
    if (flags < 0) return -1;
    return vfs_set_fd_flags(fd, (uint32_t)flags & ~((uint32_t)FD_CLOEXEC));
}

int vfs_dup(int oldfd) {
    file_t *f = vfs_get_file(oldfd);
    if (!f) return -1;

    int newfd = vfs_alloc_fd();
    if (newfd < 0) return -1;

    vfs_file_get(f);
    vfs_put_file(newfd, f);
    vfs_clear_fd_cloexec(newfd);
    return newfd;
}

int vfs_dup2(int oldfd, int newfd) {
    file_t *f = vfs_get_file(oldfd);
    if (!f || newfd < 0 || newfd >= MAX_FD) return -1;
    if (oldfd == newfd) return newfd;

    file_t *old_new = vfs_get_file(newfd);
    if (old_new) {
        vfs_put_file(newfd, NULL);
        vfs_file_put(old_new);
    }

    vfs_file_get(f);
    vfs_put_file(newfd, f);
    vfs_clear_fd_cloexec(newfd);
    return newfd;
}

int vfs_clone_cwd_for_process(void *dst_proc, void *src_proc) {
    if (!dst_proc || !src_proc)
        return -1;

    process_t *dst = (process_t *)dst_proc;
    process_t *src = (process_t *)src_proc;
    char normalized[MAX_PATH];

    if (vfs_normalize_path(src->cwd[0] ? src->cwd : "/", normalized, sizeof(normalized)) < 0)
        return -1;
    if (!vfs_path_lookup(normalized))
        return -1;

    strncpy(dst->cwd, normalized, sizeof(dst->cwd) - 1);
    dst->cwd[sizeof(dst->cwd) - 1] = 0;
    return 0;
}

int vfs_clone_fds_for_process(void *dst_proc, void *src_proc) {
    if (!dst_proc || !src_proc)
        return -1;

    process_t *dst = (process_t *)dst_proc;
    process_t *src = (process_t *)src_proc;

    for (int i = 0; i < MAX_FD; i++) {
        file_t *file = (file_t *)src->fds[i];
        if (!file || (src->fd_flags[i] & FD_CLOEXEC))
            continue;
        vfs_file_get(file);
        if (dst->fds[i])
            vfs_file_put((file_t *)dst->fds[i]);
        dst->fds[i] = file;
        dst->fd_flags[i] = src->fd_flags[i] & ~((uint32_t)FD_CLOEXEC);
    }

    return 0;
}

int vfs_close_fd_for_process(void *proc, int fd) {
    if (!proc || fd < 0 || fd >= MAX_FD)
        return -1;

    process_t *p = (process_t *)proc;
    file_t *file = (file_t *)p->fds[fd];
    if (!file)
        return -1;

    p->fds[fd] = NULL;
    p->fd_flags[fd] = 0;
    vfs_file_put(file);
    return 0;
}

int vfs_pipe(int pipefd[2]) {
    if (!pipefd) return -1;

    file_t **fds = get_current_fd_table();
    if (!fds) return -1;

    int rfd = -1;
    int wfd = -1;
    for (int i = 3; i < MAX_FD; i++) {
        if (!fds[i]) {
            if (rfd < 0) {
                rfd = i;
            } else {
                wfd = i;
                break;
            }
        }
    }
    if (rfd < 0 || wfd < 0) return -1;

    vfs_pipe_t *p = vfs_pipe_alloc_obj();
    if (!p) return -1;

    file_t *rf = (file_t *)pmm_alloc_page();
    if (!rf) {
        p->readers = 0;
        p->writers = 0;
        vfs_pipe_release_obj(p);
        return -1;
    }

    file_t *wf = (file_t *)pmm_alloc_page();
    if (!wf) {
        pmm_free_page(rf);
        p->readers = 0;
        p->writers = 0;
        vfs_pipe_release_obj(p);
        return -1;
    }

    memset(rf, 0, sizeof(file_t));
    memset(wf, 0, sizeof(file_t));
    rf->ref_count = 1;
    rf->fs_data = p;
    rf->ops = &vfs_pipe_read_ops;
    wf->ref_count = 1;
    wf->fs_data = p;
    wf->ops = &vfs_pipe_write_ops;

    vfs_put_file(rfd, rf);
    vfs_put_file(wfd, wf);
    vfs_clear_fd_cloexec(rfd);
    vfs_clear_fd_cloexec(wfd);
    pipefd[0] = rfd;
    pipefd[1] = wfd;
    return 0;
}

/* ============================================================
 * 文件操作
 * ============================================================ */

static int vfs_try_truncate_inode(inode_t *inode, uint32_t size);

int vfs_open(const char *path, int flags, int mode) {
    if (!path) return -1;

    dentry_t *d = vfs_path_lookup(path);
    if (!d) {
        if (!(flags & O_CREAT)) return -1;
        char parent_path[MAX_PATH];
        char name[MAX_NAME];
        if (split_parent_path(path, parent_path, name) < 0) return -1;
        dentry_t *parent = vfs_path_lookup(parent_path);
        if (!parent || !vfs_is_dir(parent->inode)) return -1;
        if (vfs_can_write(parent->inode) < 0 || vfs_can_exec(parent->inode) < 0) return -1;
        d = create_regular_file(parent, name, (uint32_t)mode);
        if (!d) return -1;
        dentry_t *real_parent = resolve_mount(parent);
        if (real_parent->inode && real_parent->inode->fs_type == PFS_MAGIC &&
            pfs_bind_created_node(real_parent, d) < 0) {
            detach_child(d);
            free_dentry(d);
            return -1;
        }
    }

    d = resolve_mount(d);
    if (!d || !d->inode) return -1;
    if (vfs_is_file(d->inode)) {
        inode_t *parent_inode = d->parent ? resolve_mount(d->parent)->inode : NULL;
        vfs_repair_memory_inode(d->inode, parent_inode);
    }
    if (vfs_is_dir(d->inode) && is_open_write(flags)) return -1;

    if (is_open_read(flags) && vfs_can_read(d->inode) < 0) return -1;
    if (is_open_write(flags) && vfs_can_write(d->inode) < 0) return -1;

    if ((flags & O_TRUNC) && is_open_write(flags)) {
        if (vfs_try_truncate_inode(d->inode, 0) < 0) return -1;
    }

    int fd = vfs_alloc_fd();
    if (fd < 0) return -1;

    file_t *f = (file_t *)pmm_alloc_page();
    if (!f) {
        vfs_put_file(fd, NULL);
        return -1;
    }
    memset(f, 0, sizeof(file_t));
    f->inode = d->inode;
    f->dentry = d;
    f->flags = (uint32_t)flags;
    f->offset = 0;
    f->ref_count = 1;
    f->ops = d->inode->ops;

    if (f->ops && f->ops->open) {
        if (!vfs_callback_is_sane((const void *)f->ops->open)) {
            serial_write("[VFS] bad open callback path=");
            serial_write((char *)path);
            serial_write(" inode=");
            serial_write_hex((uint32_t)f->inode);
            serial_write(" ops=");
            serial_write_hex((uint32_t)f->ops);
            serial_write(" open=");
            serial_write_hex((uint32_t)f->ops->open);
            serial_write("\n");
            vfs_put_file(fd, NULL);
            pmm_free_page(f);
            return -1;
        }
        if (f->ops->open(f) < 0) {
            vfs_put_file(fd, NULL);
            pmm_free_page(f);
            return -1;
        }
    }

    vfs_put_file(fd, f);
    vfs_clear_fd_cloexec(fd);
    return fd;
}

int vfs_close(int fd) {
    file_t *f = vfs_get_file(fd);
    if (!f) return -1;
    vfs_put_file(fd, NULL);
    vfs_clear_fd_cloexec(fd);
    vfs_file_put(f);
    return 0;
}

void vfs_close_fds_for_process(void *proc) {
    process_t *p = (process_t *)proc;
    if (!p) return;

    for (int i = 0; i < MAX_FD; i++) {
        file_t *f = (file_t *)p->fds[i];
        p->fds[i] = NULL;
        p->fd_flags[i] = 0;
        vfs_file_put(f);
    }
}

int vfs_read(int fd, void *buf, uint32_t count) {
    file_t *f = vfs_get_file(fd);
    if (!f || !buf) return -1;
    if (!is_open_read((int)f->flags)) return -1;
    if (vfs_is_dir(f->inode)) return -1;
    if (vfs_can_read(f->inode) < 0) return -1;
    if (!f->ops || !f->ops->read) return -1;
    int n = f->ops->read(f, buf, count);
    if (n > 0) vfs_touch_atime(f->inode);
    return n;
}

int vfs_write(int fd, const void *buf, uint32_t count) {
    file_t *f = vfs_get_file(fd);
    if (!f || !buf) {
        serial_write("[VFS-W] bad fd/buf\n");
        return -1;
    }
    if (!is_open_write((int)f->flags)) {
        serial_write("[VFS-W] not writable flags=");
        serial_write_hex(f->flags);
        serial_write("\n");
        return -1;
    }
    if (vfs_is_dir(f->inode)) {
        serial_write("[VFS-W] is dir mode=");
        serial_write_hex(f->inode ? f->inode->mode : 0);
        serial_write("\n");
        return -1;
    }
    if (vfs_can_write(f->inode) < 0) return -1;

    if (vfs_is_file(f->inode) && (!f->ops || !f->ops->write || f->inode->fs_type == 0)) {
        vfs_repair_memory_inode(f->inode, NULL);
        f->ops = f->inode->ops;
    }

    int ret = -1;
    if (f->ops && f->ops->write) {
        ret = f->ops->write(f, buf, count);
    } else {
        serial_write("[VFS-W] no write ops mode=");
        serial_write_hex(f->inode ? f->inode->mode : 0);
        serial_write(" ops=");
        serial_write_hex((uint32_t)f->ops);
        serial_write("\n");
    }

    /* 临时兼容：只允许 ramfs/tmpfs 普通文件走内存文件写入兜底。
     * 不能对 exFAT/块文件系统等其它 inode 盲目调用 ramfs 写逻辑，
     * 否则 fs_data 布局不匹配，可能污染函数指针并触发异常。
     */
    if (ret < 0 && vfs_is_file(f->inode) &&
        (f->inode->fs_type == RAMFS_MAGIC || f->inode->fs_type == TMPFS_MAGIC)) {
        serial_write("[VFS-W] fallback memoryfs write\n");
        ret = ramfs_write_fallback(f, buf, count);
    }

    if (ret < 0) {
        serial_write("[VFS-W] fs write failed mode=");
        serial_write_hex(f->inode ? f->inode->mode : 0);
        serial_write(" size=");
        serial_write_hex(f->inode ? f->inode->size : 0);
        serial_write(" off=");
        serial_write_hex(f->offset);
        serial_write(" count=");
        serial_write_hex(count);
        serial_write(" fs_type=");
        serial_write_hex(f->inode ? f->inode->fs_type : 0);
        serial_write(" fs_data=");
        serial_write_hex((uint32_t)(f->inode ? f->inode->fs_data : 0));
        serial_write(" write=");
        serial_write_hex((uint32_t)((f->ops && f->ops->write) ? f->ops->write : 0));
        serial_write("\n");
    } else if (ret > 0) {
        vfs_touch_mtime(f->inode);
    }
    return ret;
}

int vfs_seek(int fd, int offset, int whence) {
    file_t *f = vfs_get_file(fd);
    if (!f) return -1;

    if (f->ops && f->ops->seek) {
        return f->ops->seek(f, offset, whence);
    }

    /* Fallback: 普通文件可由 VFS 根据 inode size 维护偏移。
     * 这能兼容尚未实现 seek 回调的简单文件系统节点，
     * 例如 echo >> file 需要 SEEK_END 定位到文件尾。
     */
    if (!vfs_is_file(f->inode)) return -1;

    uint32_t base;
    switch (whence) {
    case SEEK_SET:
        base = 0;
        break;
    case SEEK_CUR:
        base = f->offset;
        break;
    case SEEK_END:
        base = f->inode ? f->inode->size : 0;
        break;
    default:
        return -1;
    }

    if (offset < 0 && (uint32_t)(-offset) > base) return -1;
    f->offset = offset < 0 ? base - (uint32_t)(-offset) : base + (uint32_t)offset;
    return (int)f->offset;
}

int vfs_fsync(int fd) {
    file_t *f = vfs_get_file(fd);
    if (!f) return -1;
    if (f->ops && f->ops->fsync) return f->ops->fsync(f);
    return blockdev_flush_all();
}

int vfs_stat(const char *path, inode_t *st) {
    if (!st) return -1;
    dentry_t *d = vfs_path_lookup(path);
    if (!d || !d->inode) return -1;
    memcpy(st, d->inode, sizeof(inode_t));
    return 0;
}

int vfs_truncate(const char *path, uint32_t size) {
    dentry_t *d = vfs_path_lookup(path);
    if (!d || !d->inode) return -1;
    if (!vfs_is_file(d->inode)) return -1;
    if (vfs_can_write(d->inode) < 0) return -1;
    if (!d->inode->ops || !d->inode->ops->truncate) return -1;
    int rc = d->inode->ops->truncate(d->inode, size);
    if (rc >= 0) vfs_touch_mtime(d->inode);
    return rc;
}

static int vfs_try_truncate_inode(inode_t *inode, uint32_t size) {
    if (!inode || !vfs_is_file(inode)) return -1;
    if (vfs_can_write(inode) < 0) return -1;
    if (!inode->ops || !inode->ops->truncate) return -1;
    int rc = inode->ops->truncate(inode, size);
    if (rc >= 0) vfs_touch_mtime(inode);
    return rc;
}

/* ============================================================
 * 目录/节点操作
 * ============================================================ */

int vfs_mkdir(const char *path, int mode) {
    char parent_path[MAX_PATH];
    char name[MAX_NAME];
    if (split_parent_path(path, parent_path, name) < 0) return -1;
    if (vfs_path_lookup(path)) return -1;
    dentry_t *parent = vfs_path_lookup(parent_path);
    if (!parent || !vfs_is_dir(parent->inode)) return -1;
    if (vfs_can_write(parent->inode) < 0 || vfs_can_exec(parent->inode) < 0) return -1;
    dentry_t *d = vfs_create_node_under(parent, name, FS_DIR | (uint32_t)mode, NULL, NULL, 0);
    if (!d) return -1;
    dentry_t *real_parent = resolve_mount(parent);
    if (real_parent->inode && real_parent->inode->fs_type == PFS_MAGIC &&
        pfs_bind_created_node(real_parent, d) < 0) {
        detach_child(d);
        free_dentry(d);
        return -1;
    }
    return 0;
}

int vfs_mknod(const char *path, int mode, const char *dev_name) {
    if (!dev_name) return -1;
    char parent_path[MAX_PATH];
    char name[MAX_NAME];
    if (split_parent_path(path, parent_path, name) < 0) return -1;
    if (vfs_path_lookup(path)) return -1;
    dentry_t *parent = vfs_path_lookup(parent_path);
    if (!parent || !vfs_is_dir(parent->inode)) return -1;
    if (vfs_can_write(parent->inode) < 0 || vfs_can_exec(parent->inode) < 0) return -1;

    if ((mode & FS_BLOCK_DEVICE) == FS_BLOCK_DEVICE) {
        blockdev_t *bd = blockdev_find(dev_name);
        if (!bd) return -1;
        return vfs_create_node_under(parent, name, FS_BLOCK_DEVICE | S_IRUSR | S_IWUSR,
                                     &vfs_blockdev_ops, bd, blockdev_size_bytes(bd)) ? 0 : -1;
    }

    chardev_t *cd = chardev_find(dev_name);
    if (!cd) return -1;
    return vfs_create_node_under(parent, name, FS_CHAR_DEVICE | S_IRUSR | S_IWUSR,
                                 &vfs_chardev_ops, cd, 0) ? 0 : -1;
}

int vfs_unlink(const char *path) {
    dentry_t *d = vfs_path_lookup(path);
    if (!d || d == root_dentry || !d->parent || !d->inode) return -1;
    if (vfs_is_dir(d->inode)) return -1;
    if (d->mount) return -1;
    if (vfs_can_write(d->parent->inode) < 0 || vfs_can_exec(d->parent->inode) < 0) return -1;
    if (d->inode->fs_type == PFS_MAGIC && pfs_remove_node(d) < 0) return -1;
    if (d->inode->nlinks > 0) d->inode->nlinks--;
    detach_child(d);
    free_dentry(d);
    return 0;
}

int vfs_rmdir(const char *path) {
    dentry_t *d = vfs_path_lookup(path);
    if (!d || d == root_dentry || !d->parent || !d->inode) return -1;
    if (!vfs_is_dir(d->inode)) return -1;
    if (d->mount) return -1;
    if (vfs_can_write(d->parent->inode) < 0 || vfs_can_exec(d->parent->inode) < 0) return -1;
    if (has_children(d)) return -1;
    if (d->inode->fs_type == PFS_MAGIC && pfs_remove_node(d) < 0) return -1;
    detach_child(d);
    free_dentry(d);
    return 0;
}

/* ============================================================
 * 新增 VFS 接口占位
 * ============================================================ */
int vfs_chdir(const char *path) {
    char norm[MAX_PATH];
    if (vfs_normalize_path(path, norm, sizeof(norm)) < 0) return -1;
    dentry_t *d = vfs_path_lookup(norm);
    if (!d || !vfs_is_dir(d->inode)) return -1;
    if (vfs_can_exec(d->inode) < 0) return -1;

    char *cwd = vfs_get_cwd();
    strncpy(cwd, norm, MAX_PATH - 1);
    cwd[MAX_PATH - 1] = 0;
    return 0;
}

int vfs_getcwd(char *buf, uint32_t size) {
    if (!buf || size < 2) return -1;
    const char *cwd = vfs_get_cwd();
    uint32_t len = (uint32_t)strlen(cwd);
    if (len + 1 > size) return -1;
    strncpy(buf, cwd, size);
    return 0;
}

int vfs_rename(const char *oldpath, const char *newpath) {
    char new_parent_path[MAX_PATH];
    char new_name[MAX_NAME];

    if (!oldpath || !newpath) return -1;
    dentry_t *old = vfs_path_lookup(oldpath);
    if (!old || old == root_dentry || !old->parent || !old->inode) return -1;
    if (old->mount) return -1;

    if (split_parent_path(newpath, new_parent_path, new_name) < 0) return -1;
    dentry_t *new_parent = vfs_path_lookup(new_parent_path);
    if (!new_parent || !vfs_is_dir(new_parent->inode)) return -1;
    if (vfs_can_write(old->parent->inode) < 0 || vfs_can_exec(old->parent->inode) < 0) return -1;
    if (vfs_can_write(new_parent->inode) < 0 || vfs_can_exec(new_parent->inode) < 0) return -1;
    if (find_child(new_parent, new_name)) return -1;

    detach_child(old);
    strncpy(old->name, new_name, MAX_NAME - 1);
    old->name[MAX_NAME - 1] = 0;
    add_child(new_parent, old);
    return 0;
}

int vfs_link(const char *oldpath, const char *newpath) {
    char parent_path[MAX_PATH];
    char name[MAX_NAME];
    dentry_t *old;
    dentry_t *parent;
    dentry_t *link;

    if (!oldpath || !newpath) return -1;

    old = vfs_path_lookup(oldpath);
    if (!old || !old->inode) return -1;
    if (vfs_is_dir(old->inode)) return -1;
    if (old->mount) return -1;

    if (split_parent_path(newpath, parent_path, name) < 0) return -1;
    parent = vfs_path_lookup(parent_path);
    if (!parent || !vfs_is_dir(parent->inode)) return -1;
    if (vfs_can_write(parent->inode) < 0 || vfs_can_exec(parent->inode) < 0) return -1;
    if (find_child(parent, name)) return -1;

    link = alloc_dentry();
    if (!link) return -1;
    strncpy(link->name, name, MAX_NAME - 1);
    link->name[MAX_NAME - 1] = 0;
    link->inode = old->inode;
    link->inode->ref_count++;
    link->inode->nlinks++;
    add_child(parent, link);
    return 0;
}

int vfs_symlink(const char *target, const char *linkpath) {
    char parent_path[MAX_PATH];
    char name[MAX_NAME];
    dentry_t *parent;
    dentry_t *link;
    inode_t *inode;
    char *stored;
    uint32_t len;

    if (!target || !linkpath || !target[0]) return -1;
    len = (uint32_t)strlen(target);
    if (len >= MAX_PATH) return -1;
    if (split_parent_path(linkpath, parent_path, name) < 0) return -1;
    parent = vfs_path_lookup(parent_path);
    if (!parent || !vfs_is_dir(parent->inode)) return -1;
    if (vfs_can_write(parent->inode) < 0 || vfs_can_exec(parent->inode) < 0) return -1;
    if (find_child(parent, name)) return -1;

    stored = alloc_symlink_target();
    if (!stored) return -1;
    strcpy(stored, target);

    inode = alloc_inode();
    if (!inode) {
        free_symlink_target(stored);
        return -1;
    }
    inode->mode = FS_SYMLINK | 0777;
    inode->size = len;
    inode->nlinks = 1;
    inode->ref_count = 1;
    inode->fs_data = stored;

    link = alloc_dentry();
    if (!link) {
        free_symlink_target(stored);
        free_inode(inode);
        return -1;
    }
    strncpy(link->name, name, MAX_NAME - 1);
    link->name[MAX_NAME - 1] = 0;
    link->inode = inode;
    add_child(parent, link);
    return 0;
}

int vfs_readlink(const char *path, char *buf, uint32_t size) {
    dentry_t *d;
    const char *target;
    uint32_t len;

    if (!path || !buf || size == 0) return -1;
    d = vfs_path_lookup_internal(path, 0);
    if (!d || !vfs_is_symlink(d->inode)) return -1;
    if (vfs_can_read(d->inode) < 0) return -1;
    target = (const char *)d->inode->fs_data;
    if (!target) return -1;
    len = (uint32_t)strlen(target);
    if (len >= size) return -1;
    strcpy(buf, target);
    return (int)len;
}

int vfs_chmod(const char *path, uint32_t mode) {
    dentry_t *d = vfs_path_lookup(path);
    if (!d || !d->inode) return -1;
    if (proc_current_uid() != 0 && proc_current_uid() != d->inode->uid) return -1;
    if (d->inode->iops && d->inode->iops->chmod)
        return d->inode->iops->chmod(d->inode, mode);
    d->inode->mode = (d->inode->mode & VFS_FILE_TYPE_MASK) | (mode & ~VFS_FILE_TYPE_MASK);
    return 0;
}

int vfs_chown(const char *path, uint32_t uid, uint32_t gid) {
    dentry_t *d = vfs_path_lookup(path);
    if (!d || !d->inode) return -1;
    if (proc_current_uid() != 0) return -1;
    if (d->inode->iops && d->inode->iops->chown)
        return d->inode->iops->chown(d->inode, uid, gid);
    d->inode->uid = uid;
    d->inode->gid = gid;
    return 0;
}

dentry_t *vfs_readdir(const char *path, int index) {
    if (index < 0) return NULL;
    dentry_t *d = vfs_path_lookup(path);
    d = resolve_mount(d);
    if (!d || !vfs_is_dir(d->inode)) return NULL;
    if (vfs_can_read(d->inode) < 0 || vfs_can_exec(d->inode) < 0) return NULL;

    dentry_t *c = d->child;
    int i = 0;
    while (c) {
        if (i == index) return resolve_mount(c);
        c = c->sibling;
        i++;
    }
    return NULL;
}

/* ============================================================
 * 挂载
 * ============================================================ */

int vfs_mount(const char *path, fs_type_t *fs) {
    if (!fs) return -1;
    dentry_t *mp = vfs_path_lookup_internal(path, 0);
    if (!mp || !vfs_is_dir(mp->inode)) return -1;
    if (proc_current_uid() != 0) return -1;
    if (mp->mount) return -1;

    inode_t *root = NULL;
    if (fs->lookup) root = fs->lookup(fs, "/");
    if (!root) {
        root = alloc_inode();
        if (!root) return -1;
        root->mode = FS_DIR | S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH;
        root->uid = 0;
        root->gid = 0;
        root->fs_type = fs->magic;
        root->fs_data = fs->data;
        if (fs->magic == TMPFS_MAGIC) {
            tmpfs_setup_inode(root, root->mode);
        } else {
            ramfs_setup_inode(root, root->mode);
        }
    }

    dentry_t *md = alloc_dentry();
    if (!md) return -1;
    strcpy(md->name, mp->name);
    md->inode = root;
    md->parent = mp->parent ? mp->parent : mp;

    mp->mount = md;
    if (fs->magic == PFS_MAGIC && pfs_populate(md) < 0) {
        mp->mount = NULL;
        free_dentry(md);
        return -1;
    }

    mount_t *m = alloc_mount();
    if (!m) {
        mp->mount = NULL;
        free_dentry(md);
        return -1;
    }
    m->fs = fs;
    m->mountpoint = mp;
    m->root = root;
    m->next = mount_list;
    mount_list = m;
    return 0;
}

int vfs_umount(const char *path) {
    if (proc_current_uid() != 0) return -1;
    dentry_t *mp = vfs_path_lookup_internal(path, 0);
    if (!mp) return -1;

    mount_t **pp = &mount_list;
    while (*pp) {
        mount_t *m = *pp;
        if (m->mountpoint == mp) {
            if (!mp->mount) return -1;
            if (mp->mount->child) return -1;
            dentry_t *mounted = mp->mount;
            mp->mount = NULL;
            *pp = m->next;
            free_dentry(mounted);
            free_mount(m);
            return 0;
        }
        pp = &(*pp)->next;
    }
    return -1;
}
